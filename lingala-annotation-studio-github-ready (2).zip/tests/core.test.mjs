import test from 'node:test';
import assert from 'node:assert/strict';
import {formatTime,validateSegment,validateProject,calculateCoverage,overlapWarnings,toCSV,createDemo} from '../src/annotation-core.mjs';

test('formats seconds as MM:SS',()=>{assert.equal(formatTime(125.8),'02:05');assert.equal(formatTime(-4),'00:00');});
test('validates proper segment',()=>{assert.deepEqual(validateSegment(createDemo().segments[0]),[]);});
test('rejects out of range and empty text',()=>{const s={...createDemo().segments[0],start:4,end:2,text:'  '};assert.equal(validateSegment(s).length,2);});
test('rejects segments longer than audio',()=>{assert.ok(validateSegment(createDemo().segments[2],5).some(e=>e.includes('exceeds')));});
test('validates whole project and duplicate IDs',()=>{const p=createDemo();p.segments[1].id=p.segments[0].id;assert.ok(validateProject(p).some(e=>e.includes('duplicate')));});
test('calculates union of timeline ranges, not simple sum',()=>{assert.equal(calculateCoverage([{start:0,end:3},{start:2,end:5},{start:7,end:8}]),6);});
test('warns about same speaker overlap only',()=>{const p=createDemo();p.segments[1].start=1;assert.equal(overlapWarnings(p.segments).length,0);p.segments[1].speaker='SPK_01';assert.equal(overlapWarnings(p.segments).length,1);});
test('escapes CSV spreadsheet delimiters and quotes',()=>{const p=createDemo();p.segments[0].text='Mbote, "malamu"\nndeko';const csv=toCSV(p);assert.ok(csv.includes('"Mbote, ""malamu""\nndeko"'));assert.ok(csv.startsWith('id,start,end,'));});
