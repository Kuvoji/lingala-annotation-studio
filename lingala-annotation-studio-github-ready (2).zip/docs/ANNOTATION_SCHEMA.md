# Annotation file format

Exports are JSON UTF-8 files in this schema:

```json
{
  "schema_version": 1,
  "name": "example-session",
  "language": "ln",
  "segments": [
    {
      "id": "unique-segment-id",
      "start": 1.25,
      "end": 3.5,
      "speaker": "SPK_01",
      "text": "Mbote, ozali malamu?",
      "condition": "clean",
      "note": "Optional reviewer note"
    }
  ]
}
```

- Timestamps use **seconds** relative to the recording start.
- `language` is `ln` (Lingala), `en` (English), or `ln-en` (mixed).
- `condition` is `clean`, `background_noise`, `overlapping_speech`, or `unclear`.
- `speaker` may contain letters, digits, underscores, and hyphens, up to 30 characters.
- The `text` field is verbatim; this project **does not automatically translate or transcribe audio**.
- Cross-speaker overlap is permitted; same-speaker overlap is shown as a review warning.
- A CSV export contains segment fields plus project name and language. Import currently supports JSON only.

## Privacy and limitations

Audio is **not** uploaded to a service. It is loaded into your current tab and never bundled in exported annotation JSON. Annotation text may include personal information: check permissions and apply your organization's privacy guidelines before sharing any dataset. Browser local storage saves **annotation text** (not audio), so use Export JSON for backups. Large audio files may play without a waveform preview. This is a portfolio demonstration, not a validated production transcription system.
