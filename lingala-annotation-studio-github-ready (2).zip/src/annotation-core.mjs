/** Pure data operations shared by the interface and the test suite. */
export const CONDITIONS = ['clean','background_noise','overlapping_speech','unclear'];
export const LANGUAGES = ['ln','en','ln-en'];

export function formatTime(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  const minutes = Math.floor(total / 60);
  return `${String(minutes).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
}

export function validateSegment(s, duration = null) {
  const problems = [];
  if (!Number.isFinite(Number(s.start)) || Number(s.start) < 0) problems.push('Start time must be a nonnegative number.');
  if (!Number.isFinite(Number(s.end)) || Number(s.end) <= Number(s.start)) problems.push('End time must be later than start time.');
  if (Number(s.end) < 0 || !Number.isFinite(Number(s.end))) problems.push('End time must be valid.');
  if (duration != null && Number.isFinite(duration) && duration > 0 && Number(s.end) > duration + 0.02) problems.push('Segment exceeds recording duration.');
  if (!/^[a-zA-Z0-9_-]{1,30}$/.test(String(s.speaker ?? ''))) problems.push('Speaker ID must use letters, numbers, _ or -.');
  if (!String(s.text ?? '').trim()) problems.push('Transcript cannot be empty.');
  if (!CONDITIONS.includes(s.condition)) problems.push('Select a valid acoustic condition.');
  return [...new Set(problems)];
}

export function validateProject(project, duration = null) {
  const problems = [];
  if (!project || typeof project !== 'object' || Array.isArray(project)) return ['Project must be a JSON object.'];
  if (!Array.isArray(project.segments)) return ['Project segments must be an array.'];
  if (!LANGUAGES.includes(project.language)) problems.push('Recording language is not supported.');
  const ids = new Set();
  for (const [index, s] of project.segments.entries()) {
    if (!s || typeof s !== 'object' || Array.isArray(s)) { problems.push(`Segment ${index + 1} is invalid.`); continue; }
    if (typeof s.id !== 'string' || !s.id || ids.has(s.id)) problems.push(`Segment ${index + 1} has a missing or duplicate ID.`);
    ids.add(s.id);
    for (const problem of validateSegment(s, duration)) problems.push(`Segment ${index + 1}: ${problem}`);
  }
  return problems;
}

export function calculateCoverage(segments) {
  const ranges = segments.map(s => [Number(s.start), Number(s.end)]).filter(([s, e]) => Number.isFinite(s) && Number.isFinite(e) && e > s).sort((a,b) => a[0]-b[0]);
  if (!ranges.length) return 0;
  let total = 0, [start, end] = ranges[0];
  for (const [a,b] of ranges.slice(1)) {
    if (a <= end) end = Math.max(end, b);
    else { total += end-start; [start, end] = [a,b]; }
  }
  return total + end - start;
}

export function overlapWarnings(segments) {
  const warnings = [];
  const sorted = [...segments].sort((a,b) => a.start-b.start);
  for (let i = 0; i < sorted.length; i++) {
    for (let j = i+1; j < sorted.length && Number(sorted[j].start) < Number(sorted[i].end); j++) {
      if (sorted[i].speaker === sorted[j].speaker) warnings.push(`Segments for ${sorted[i].speaker} overlap (${formatTime(sorted[j].start)}).`);
    }
  }
  return warnings;
}

export function csvEscape(value) {
  const str = String(value ?? '');
  return /[",\n\r]/.test(str) ? `"${str.replaceAll('"', '""')}"` : str;
}

export function toCSV(project) {
  const keys = ['id','start','end','speaker','text','condition','note','language','project_name'];
  const rows = project.segments.map(s => keys.map(k => csvEscape(k === 'language' ? project.language : k === 'project_name' ? project.name : s[k])).join(','));
  return [keys.join(','), ...rows].join('\r\n') + '\r\n';
}

export function createDemo() {
  return {
    schema_version: 1, name: 'Demo · Lingala dialogue', language: 'ln',
    segments: [
      {id:'demo-1',start:0.2,end:2.3,speaker:'SPK_01',text:'Mbote, ozali malamu?',condition:'clean',note:'Greeting'},
      {id:'demo-2',start:2.6,end:4.4,speaker:'SPK_02',text:'Nazali malamu, matondo.',condition:'clean',note:''},
      {id:'demo-3',start:4.8,end:7.1,speaker:'SPK_01',text:'Tokomonana lobi.',condition:'background_noise',note:'Illustrative noise tag'}
    ]
  };
}
