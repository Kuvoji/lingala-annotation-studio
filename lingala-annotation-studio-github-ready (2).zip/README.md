# Lingala Annotation Studio

**A local-first speech annotation workspace built for human reviewers of Lingala and multilingual audio.**

![JavaScript](https://img.shields.io/badge/JavaScript-ES_Modules-f7df1e?logo=javascript&logoColor=111)
![Tests](https://img.shields.io/badge/Tests-Node.js_builtin-54c6a9)
![License](https://img.shields.io/badge/License-MIT-blue)

> Portfolio project by **Angeline Kuvoji**, Linguistic Data Specialist and Lingala Speech Contributor. The included recordings/transcripts are illustrative examples, not evidence of a client deliverable or certified dataset quality.

## Why it exists

Human-in-the-loop speech datasets need consistent timestamp boundaries, speaker labels, verbatim transcripts, and a simple way to review noisy or overlapping speech. This browser-based application provides these steps **without transferring raw audio to a backend**.

## Features

- 🎙️ Open local audio and see a waveform (where supported) with play/pause, seek, speed adjustment and ±2s controls.
- ✍🏾 Timestamp segments, label speakers, and store acoustic condition and reviewer notes.
- ⌨️ Quick shortcuts: **Space** play/pause, **[** mark segment start, **]** mark end.
- ✅ Inline checks for invalid timestamps, empty transcript, malformed speaker ID, out-of-audio bounds, and same-speaker overlaps.
- 🔎 Filter annotations and replay, edit, or remove individual segments.
- 📦 Export annotation data as **JSON** or **CSV**, with JSON import and browser-local autosave.
- 🔐 Local-only audio; no API keys, trackers, remote database, or uploaded sample files.
- 📱 Responsive interface suitable for laptop and tablet screens.

## Demo preview

A working demo is available by deploying this repository to **GitHub Pages**. Click **Load demo** to see example annotations without providing audio; select any audio file for playback. No screenshots or recordings are required to run the project.

## Run locally

Python 3 is sufficient to launch a local web server (Node.js is needed **only** for automated tests).

```bash
# In the folder containing index.html
python -m http.server 8000
```

Open **http://localhost:8000** in your browser. A web server is recommended because browsers may block module imports when opening `index.html` via `file://`.

```bash
# Optional: run unit tests with Node.js 20+
npm test
```

No dependency installation is required.

## Deploy to GitHub Pages

1. Create a new repository named `lingala-annotation-studio`.
2. Unzip the archive and upload **the contents of the extracted folder** to the **root of the repository**.
3. Open **Settings → Pages → Build and deployment**; choose **Deploy from a branch**, `main`, `/ (root)`; save.
4. Open the GitHub Pages URL shown under Pages. The application runs entirely in the viewer's browser.

## Example workflow

1. Load your consented recording from your own computer.
2. Set project name and language (`ln`, `en`, or `ln-en`).
3. Play the audio and click **Mark** for start/end timestamps.
4. Add speaker ID, verbatim words and acoustic condition.
5. Review any flagged problems and export validated JSON or CSV.

File structure:

```text
lingala-annotation-studio/
├── index.html                 # Application UI
├── assets/
│   ├── styles.css             # Responsive dark theme
│   └── app.js                 # Application orchestration, audio controls
├── src/annotation-core.mjs    # Data model, validation and CSV export
├── tests/core.test.mjs        # Automated unit tests
├── data/demo-project.json    # Illustrative annotations
├── docs/ANNOTATION_SCHEMA.md # Dataset schema and privacy notes
└── .github/workflows/test.yml # GitHub Actions
```

## Scope

This tool creates and reviews **manual** transcripts. It does not run ASR or claim to generate accurate transcripts automatically. The waveform is a visual aid, not a sample-accurate forced aligner. Always obtain recording consent and comply with applicable data handling requirements.

## Author

**Angeline Kuvoji** · Lingala linguistics · Speech annotation · AI data quality

## License

MIT — see [LICENSE](LICENSE).
