import { CONDITIONS, LANGUAGES, formatTime, validateSegment, validateProject, calculateCoverage, overlapWarnings, toCSV, createDemo } from '../src/annotation-core.mjs';

const $ = (id) => document.getElementById(id);
const STORAGE_KEY = 'lingala-annotation-studio-v1';
const audio = $('audio');
let project = { schema_version: 1, name: 'Untitled project', language: 'ln', segments: [] };
let editingId = null;
let audioUrl = null;
let samplePeaks = null;
let loopSegmentEnd = null;
let waveformDuration = null;
let noticeTimeout = null;

function notify(message, isError=false) {
  const old = document.querySelector('.toast'); if (old) old.remove();
  if (noticeTimeout) clearTimeout(noticeTimeout);
  const el = document.createElement('div'); el.className = `toast${isError ? ' error' : ''}`;
  el.setAttribute('role', 'status'); el.textContent = message; document.body.append(el);
  noticeTimeout = setTimeout(() => el.remove(), 3800);
}
function saveLocal() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(project)); $('saveStatus').textContent = 'Saved locally'; }
  catch { $('saveStatus').textContent = 'Storage unavailable'; notify('Could not save locally. Export JSON to avoid data loss.', true); }
}
function resetForm() {
  editingId = null; $('segmentForm').reset(); $('start').value = '0'; $('end').value = '2';
  $('speaker').value = 'SPK_01'; $('saveSegmentBtn').textContent = '+ Add segment'; $('modeIndicator').textContent = 'NEW SEGMENT';
}
function fillForm(s) {
  editingId = s.id; $('start').value = s.start; $('end').value = s.end; $('speaker').value = s.speaker;
  $('transcript').value = s.text; $('condition').value = s.condition; $('note').value = s.note || '';
  $('saveSegmentBtn').textContent = 'Save changes'; $('modeIndicator').textContent = 'EDIT SEGMENT';
  $('segmentForm').scrollIntoView({behavior:'smooth',block:'center'});
}
function render() {
  $('projectName').value = project.name;
  $('language').value = project.language;
  $('sideProject').textContent = project.name;
  const segments = [...project.segments].sort((a,b) => Number(a.start)-Number(b.start));
  $('metricSegments').textContent = String(segments.length);
  $('segmentCount').textContent = String(segments.length);
  $('metricSpeakers').textContent = String(new Set(segments.map(s=>s.speaker)).size);
  $('metricDuration').textContent = formatTime(calculateCoverage(segments));
  const errors = validateProject(project, Number.isFinite(audio.duration) ? audio.duration : null);
  const warnings = overlapWarnings(segments);
  $('metricIssues').textContent = `${errors.length + warnings.length} issue${errors.length + warnings.length === 1 ? '' : 's'}`;
  const score = Math.max(0, 100 - errors.length * 20 - warnings.length * 5);
  $('qualityScore').innerHTML = `${score}<span>%</span>`;
  $('qualitySummary').textContent = errors.length ? `${errors.length} validation error${errors.length===1?'':'s'}` : warnings.length ? 'Review suggested' : 'Checks passed';
  const checks = [
    {message: 'Timestamp boundaries are valid', ok: !errors.some(s => /time|duration|exceeds/i.test(s))},
    {message: 'All speaker labels follow ID rules', ok: !errors.some(s => /Speaker ID/i.test(s))},
    {message: 'Transcripts are not empty', ok: !errors.some(s => /Transcript/i.test(s))},
    {message: 'Recording language and tags are valid', ok: !errors.some(s => /language|acoustic condition/i.test(s))},
    {message: warnings.length ? `${warnings.length} potential overlapping segment(s)` : 'No same-speaker timeline overlaps', ok: warnings.length === 0}
  ];
  const quality = $('qualityList'); quality.replaceChildren();
  for (const check of checks) {
    const row = document.createElement('div'); row.className = 'quality-row';
    const symbol = document.createElement('span'); symbol.className = check.ok ? 'check' : 'check warn'; symbol.textContent = check.ok ? '✓' : '!';
    const label = document.createElement('span'); label.textContent = check.message; row.append(symbol,label); quality.append(row);
  }
  for (const error of errors.slice(0,3)) {
    const row = document.createElement('div'); row.className = 'quality-row'; const symbol = document.createElement('span');
    symbol.className = 'check warn'; symbol.textContent = '!'; const label = document.createElement('span'); label.textContent = error;
    row.append(symbol,label); quality.append(row);
  }
  const filter = $('search').value.trim().toLocaleLowerCase();
  const body = $('segmentsBody'); body.replaceChildren();
  const filtered = segments.filter(s => `${s.text} ${s.speaker} ${s.condition}`.toLocaleLowerCase().includes(filter));
  for (const s of filtered) {
    const tr = document.createElement('tr');
    const time = document.createElement('td'); time.className = 'time-cell'; time.textContent = `${formatTime(s.start)}–${formatTime(s.end)}`;
    const speaker = document.createElement('td'); const speakerTag = document.createElement('span'); speakerTag.className='speaker-tag'; speakerTag.textContent=s.speaker; speaker.append(speakerTag);
    const transcript = document.createElement('td'); transcript.className='text-col'; transcript.textContent = s.text;
    const condition = document.createElement('td'); const conditionTag=document.createElement('span'); conditionTag.className='condition-label'; conditionTag.textContent=s.condition.replaceAll('_',' '); condition.append(conditionTag);
    const actions=document.createElement('td');
    const play=makeRowButton('▶','Play segment',()=>playSegment(s)); const edit=makeRowButton('✎','Edit segment',()=>fillForm(s));
    const del=makeRowButton('✕','Delete segment',()=>{if(confirm('Delete this segment?')){project.segments=project.segments.filter(p=>p.id!==s.id);if(editingId===s.id)resetForm(); saveLocal();render();}});
    del.classList.add('danger'); actions.append(play,edit,del);
    tr.append(time,speaker,transcript,condition,actions); body.append(tr);
  }
  $('emptyState').hidden = filtered.length !== 0;
  $('emptyState').textContent = segments.length ? 'No segments match this search.' : 'No segments yet. Load the demo or add your first annotated utterance.';
  renderWaveform();
}
function makeRowButton(glyph, label, fn) {
  const button = document.createElement('button'); button.type='button'; button.className='row-action'; button.textContent=glyph;
  button.title=label; button.setAttribute('aria-label',label); button.addEventListener('click',fn); return button;
}
function playSegment(s) {
  if (!audio.src) { notify('Select an audio file to replay segments. Demo annotations are text-only.', true); return; }
  loopSegmentEnd=Number(s.end); audio.currentTime=Math.min(Number(s.start),audio.duration || Number(s.start));
  audio.play().catch(()=>notify('Audio playback is blocked by your browser.',true));
}
function download(filename, text, mime) {
  const url=URL.createObjectURL(new Blob([text],{type:mime})); const link=document.createElement('a');link.href=url;link.download=filename;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),250);
}
function safeName(name) { return (name || 'annotations').normalize('NFKD').replace(/[^a-zA-Z0-9_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,45) || 'annotations'; }
function exportProject(kind) {
  const errors=validateProject(project, Number.isFinite(audio.duration) ? audio.duration : null);
  if(errors.length){notify(`Resolve ${errors.length} validation error(s) before exporting.`,true);return;}
  const base=safeName(project.name);
  if(kind==='csv') download(`${base}.csv`,toCSV(project),'text/csv;charset=utf-8');
  else download(`${base}.json`,JSON.stringify(project,null,2)+'\n','application/json;charset=utf-8');
  notify(`Exported ${kind.toUpperCase()} successfully.`);
}
function loadProject(parsed) {
  const errors=validateProject(parsed);
  if(errors.length) throw new Error(errors.slice(0,3).join(' '));
  if(parsed.segments.length > 3000) throw new Error('Project exceeds the 3,000 segment import limit.');
  project={schema_version:1,name:String(parsed.name ?? 'Imported project').slice(0,80),language:parsed.language,segments:parsed.segments.map(s=>({id:s.id,start:Number(s.start),end:Number(s.end),speaker:s.speaker,text:String(s.text),condition:s.condition,note:String(s.note??'').slice(0,300)}))};
  resetForm(); saveLocal(); render();
}
function togglePlayback() {
  if(!audio.src) {notify('Choose an audio file first, or load the annotation demo.', true);return;}
  if(audio.paused){ loopSegmentEnd=null; audio.play().catch(()=>notify('Playback could not start.',true)); }
  else audio.pause();
}
function drawWave() {
  const canvas=$('waveform');const rect=canvas.getBoundingClientRect();const ratio=window.devicePixelRatio || 1;
  if(rect.width<1)return;
  canvas.width=Math.round(rect.width*ratio);canvas.height=Math.round(rect.height*ratio);
  const ctx=canvas.getContext('2d');const w=rect.width,h=rect.height;ctx.scale(ratio,ratio);
  ctx.clearRect(0,0,w,h);ctx.fillStyle='#14263b';ctx.fillRect(0,0,w,h);
  ctx.strokeStyle='#1e3448';ctx.lineWidth=1;
  for(let i=1;i<5;i++){let x=w*i/5;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
  const duration=Number.isFinite(audio.duration)&&audio.duration>0 ? audio.duration : Math.max(...project.segments.map(s=>Number(s.end)),10);
  waveformDuration=duration;
  for(const s of project.segments){const left=Math.max(0,Number(s.start)/duration*w);const right=Math.min(w,Number(s.end)/duration*w);ctx.fillStyle=s.condition==='background_noise'?'#bc864824':'#59d8c31d';ctx.fillRect(left,0,right-left,h);}
  ctx.strokeStyle='#53cdb8';ctx.lineWidth=1.7;
  const mid=h/2;
  for(let x=0;x<w;x+=3){const i=Math.min((samplePeaks?.length || 1)-1,Math.floor(x/w*(samplePeaks?.length || 1)));
    const amp=samplePeaks ? samplePeaks[i] : (0.1+0.1*Math.abs(Math.sin(x*.035))+0.09*Math.abs(Math.sin(x*.21))) ;
    const radius=Math.max(3,amp*(h*.43));ctx.beginPath();ctx.moveTo(x,mid-radius);ctx.lineTo(x,mid+radius);ctx.stroke();}
  const t=Number.isFinite(audio.currentTime)?audio.currentTime:0;const x=Math.max(0,Math.min(w,t/duration*w));
  ctx.strokeStyle='#f5ca75';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();
}
function renderWaveform(){drawWave();const d=Number.isFinite(audio.duration)?audio.duration:(waveformDuration||0);$('currentTime').textContent=`${formatTime(audio.currentTime)} / ${formatTime(d)}`;$('waveEnd').textContent=formatTime(d);}

$('segmentForm').addEventListener('submit',(event)=>{
  event.preventDefault();
  const s={id:editingId || (globalThis.crypto?.randomUUID?.() || `id-${Date.now()}-${Math.random()}`),start:Number($('start').value),end:Number($('end').value),speaker:$('speaker').value.trim(),text:$('transcript').value.trim(),condition:$('condition').value,note:$('note').value.trim()};
  const problems=validateSegment(s,Number.isFinite(audio.duration) ? audio.duration : null);
  if(problems.length){notify(problems[0],true);return;}
  const idx=project.segments.findIndex(p=>p.id===s.id);
  if(idx>=0)project.segments[idx]=s;else project.segments.push(s);
  saveLocal(); resetForm(); render(); notify('Annotation segment saved.');
});
$('projectName').addEventListener('change',()=>{project.name=$('projectName').value.trim().slice(0,80)||'Untitled project';saveLocal();render();});
$('language').addEventListener('change',()=>{if(LANGUAGES.includes($('language').value)){project.language=$('language').value;saveLocal();render();}});
$('search').addEventListener('input',render);
$('markStart').addEventListener('click',()=>$('start').value=audio.currentTime.toFixed(2));
$('markEnd').addEventListener('click',()=>$('end').value=audio.currentTime.toFixed(2));
$('clearForm').addEventListener('click',resetForm);
$('playBtn').addEventListener('click',togglePlayback);
$('backBtn').addEventListener('click',()=>{if(audio.src)audio.currentTime=Math.max(0,audio.currentTime-2);});
$('forwardBtn').addEventListener('click',()=>{if(audio.src)audio.currentTime=Math.min(audio.duration || Infinity,audio.currentTime+2);});
$('speed').addEventListener('change',()=>audio.playbackRate=Number($('speed').value));
$('waveform').addEventListener('click',e=>{if(!audio.src || !Number.isFinite(audio.duration))return;const b=e.currentTarget.getBoundingClientRect();audio.currentTime=Math.max(0,Math.min(audio.duration,(e.clientX-b.left)/b.width*audio.duration));});
$('exportBtn').addEventListener('click',()=>exportProject('json'));
$('csvBtn').addEventListener('click',()=>exportProject('csv'));
$('importBtn').addEventListener('click',()=>$('importFile').click());
$('importFile').addEventListener('change',async(e)=>{
  const file=e.target.files?.[0];if(!file)return;
  try{if(file.size>5_000_000)throw new Error('JSON file is too large (max 5 MB).');if(project.segments.length&&!confirm('Replace current annotations? Export them first if needed.'))return;
    loadProject(JSON.parse(await file.text()));notify('Imported valid annotations.');
  }catch(err){notify(`Import failed: ${err.message}`,true);}finally{e.target.value='';}
});
$('demoBtn').addEventListener('click',()=>{if(project.segments.length&&!confirm('Replace current annotations with sample data?'))return;loadProject(createDemo());notify('Loaded illustrative Lingala annotations. Add audio to play.');});
$('resetBtn').addEventListener('click',()=>{if(project.segments.length&&!confirm('Start a new project? Export your annotations first.'))return;loadProject({schema_version:1,name:'Untitled project',language:'ln',segments:[]});notify('New project created.');});
$('audioFile').addEventListener('change',async(e)=>{
  const file=e.target.files?.[0];if(!file)return;
  if(!file.type.startsWith('audio/') && !/\.(wav|mp3|ogg|m4a|webm|flac)$/i.test(file.name)){notify('Choose an audio file.',true);return;}
  if(audioUrl) URL.revokeObjectURL(audioUrl);audio.pause();audioUrl=URL.createObjectURL(file);audio.src=audioUrl;samplePeaks=null;
  $('audioName').textContent=file.name;$('saveStatus').textContent='Local audio loaded';
  try{
    // Decode only files <= 40 MB for waveform rendering; playback itself has no application-imposed size limit.
    if(file.size<=40_000_000 && (window.AudioContext||window.webkitAudioContext)){
      const ctx=new (window.AudioContext||window.webkitAudioContext)();
      try {const buffer=await ctx.decodeAudioData(await file.arrayBuffer());const values=buffer.getChannelData(0);const bars=560;samplePeaks=Array.from({length:bars},(_,i)=>{let max=0;const start=Math.floor(values.length*i/bars),end=Math.floor(values.length*(i+1)/bars);const stride=Math.max(1,Math.floor((end-start)/300));for(let n=start;n<end;n+=stride)max=Math.max(max,Math.abs(values[n]));return Math.min(1,max);});}
      finally {await ctx.close();}
    }
  }catch{notify('Audio loaded, but waveform preview is unavailable for this format.');}
  render();
});
audio.addEventListener('loadedmetadata',render);
audio.addEventListener('timeupdate',()=>{if(loopSegmentEnd!==null && audio.currentTime>=loopSegmentEnd){audio.pause();loopSegmentEnd=null;}renderWaveform();});
audio.addEventListener('play',()=>$('playBtn').textContent='Ⅱ');
audio.addEventListener('pause',()=>$('playBtn').textContent='▶');
window.addEventListener('resize',drawWave);
document.addEventListener('keydown',(e)=>{if(e.altKey||e.ctrlKey||e.metaKey||['INPUT','TEXTAREA','SELECT','BUTTON'].includes(document.activeElement.tagName))return;
  if(e.code==='Space'){e.preventDefault();togglePlayback();}else if(e.key==='['){e.preventDefault();$('start').value=audio.currentTime.toFixed(2);}else if(e.key===']'){e.preventDefault();$('end').value=audio.currentTime.toFixed(2);}
});
try{const previous=localStorage.getItem(STORAGE_KEY);if(previous){const parsed=JSON.parse(previous);if(!validateProject(parsed).length && parsed.segments.length<=3000){loadProject(parsed);}}}catch{ /* Browser storage may be disabled. */ }
render();
